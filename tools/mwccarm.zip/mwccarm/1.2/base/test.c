int sub_20048D0(int);
int sub_2004018(int);
int sub_2003FF4(int);
int sub_20C3980(int, int);
void sub_200526C(int, int);

int sub_20051F4(int a1)
{
    int v2 = sub_20048D0(a1);
    int v3 = sub_2004018(v2);
    int v5 = sub_2003FF4(v3);
    int v6 = sub_20C3980(v5, a1);
    sub_200526C(a1, v3);
    return v6;
}